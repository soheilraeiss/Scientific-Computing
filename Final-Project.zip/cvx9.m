
rand('seed',314);
x=rand(40,1);
y=rand(40,1);
class=[2*x<y+0.5]+1;
A1=[x(find(class==1)),y(find(class==1))];
A2=[x(find(class==2)),y(find(class==2))];

cvx_begin
    % Variables
    variable w(2);  
    variable b;     
    variable t;     
    

    minimize(t);
    

        for i = 1:size(A1, 1)
        A1(i, :) * w + b >= 1 - t;
    end
    
    for i = 1:size(A2, 1)
        A2(i, :) * w + b <= -(1 - t);
    end


cvx_end

plot(A1(:,1),A1(:,2),'*', 'MarkerSize', 6)
hold on
plot(A2(:,1),A2(:,2),'d','MarkerSize',6)
axis([0, 1, 0, 1])


x_line = linspace(0, 1, 100);
y_line = (-w(1)*x_line - b) / w(2);
plot(x_line, y_line, 'r','LineWidth', 2);


y_line_margin1 = (-w(1)*x_line - b + 1) / w(2);
y_line_margin2 = (-w(1)*x_line - b - 1) / w(2);
plot(x_line, y_line_margin1, '--g');
plot(x_line, y_line_margin2, '--g');

hold off 